function validate(event){

    var user = document.querySelector("#user");
    var pass = document.querySelector("#pass");
    var message = document.querySelector(".error");

        if (user.value.length == 0 && pass.value.length != 0)
            {
                message.innerHTML = "Enter your username!";
                console.log('Login error');
            }

            if (user.value.length != 0 && pass.value.length == 0)
            {
                message.innerHTML = "Enter your password!";
                console.log('Login error');
            }

            if (user.value.length == 0 && pass.value.length == 0)
            {
                message.innerHTML = "Enter your username and password!";
                console.log('Login error');
            }

            if (user.value.length != 0 && pass.value.length != 0)
            {
                message.innerHTML = "";
            }
}

function showpassword() {
    var x = document.getElementById("pass");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}